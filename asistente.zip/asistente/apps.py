from django.apps import AppConfig


class AsistenteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'asistente'
    verbose_name = 'PIA - Asistente IA'